import pygame
import random
import math
from pygame import mixer 
mixer.init()
pygame.init()

mixer.music.load('background.mp3')
mixer.music.play(-1)
screen=pygame.display.set_mode((800,600))
pygame.display.set_caption('Lost in Space')
icon=pygame.image.load('space-invaders.png')
pygame.display.set_icon(icon)

background=pygame.image.load('bg.jpg')
spaceshipimg=pygame.image.load('spaceship.png')

alienimg=[]
alienX=[]
alienY=[]
alienspeedX=[]
alienspeedY=[]

no_of_aliens=20

for i in range(no_of_aliens):
    alienimg.append(pygame.image.load('alien.png'))
    alienX.append(random.randint(0,736))
    alienY.append(random.randint(30,150))
    alienspeedX.append(-0.3)
    alienspeedY.append(7)

score=0

spaceshipX=370
changeX=0
spaceshipY=480

bulletimg=pygame.image.load('bullet.png')
bulletX=386
bulletY=490
check=False
running=True

font=pygame.font.SysFont('Arial',32,'bold')

def score_text():
    img=font.render(f'SCORE : {score}',True,'orange')
    screen.blit(img,(10,10)) 

font_gameover=pygame.font.SysFont('Comic Sans',64,'bold')

def gameover():
    img_gameover=font_gameover.render(f'GAME OVER',True,'red')
    screen.blit(img_gameover,(200,250)) 

while running:
    screen.blit(background,(0,0))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            running =False
        
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                changeX=-1
            if event.key==pygame.K_RIGHT:
                changeX=1
            if event.key==pygame.K_SPACE:
                check=True
                bulletX=spaceshipX+16
                bulletSound=mixer.Sound('laser.mp3')
                bulletSound.play()
                
        if event.type==pygame.KEYUP:
            changeX=0
    spaceshipX+=changeX
    if spaceshipX<=0:
        spaceshipX=0
    elif spaceshipX>=736:
        spaceshipX=736
    for i in range(no_of_aliens):
        if alienY[i]>420:
            gameoverSound=mixer.Sound('explosion.mp3')
            gameoverSound.music.play(-1)
            for j in range(no_of_aliens):
              alienY[j]=2000
            gameover()
            break
        alienX[i]+=alienspeedX[i]
        if alienX[i]<=0:
            alienspeedX[i]=0.7
            alienY[i]+=alienspeedY[i]
        if alienX[i]>=736:
            alienspeedX[i]=-0.7
            alienY[i]+=alienspeedY[i]

        distance=math.sqrt(math.pow(bulletX-alienX[i],2)+math.pow(bulletY-alienY[i],2))
        if distance<27:
           hit=mixer.Sound('hitimpact.mp3')
           hit.play()
           bulletY=480
           check=False
           alienX[i]=random.randint(0,736)
           alienY[i]=random.randint(30,150)
           score+=1
        screen.blit(alienimg[i],(alienX[i],alienY[i]))
    if bulletY<=0:
        bulletY=490
        check=False
    if check is True:
        screen.blit(bulletimg,(bulletX,bulletY))
        bulletY-=1.75
    
    screen.blit(spaceshipimg,(spaceshipX,spaceshipY))
    score_text()
    pygame.display.update()
    