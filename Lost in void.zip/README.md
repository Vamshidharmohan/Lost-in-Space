Lost in Space: Alone in the Void Developed by Black Squad Creators: Vamshidhar Mohan, Vaishnavi S, Sushmitha S, Yeshwanth Gowda G

Game Description:

Lost in the vast expanse of space, you are an astronaut stranded in a mysterious void, far from civilization. In Lost in Space: Alone in the Void, you must navigate through perilous asteroid fields, dodge hostile alien ships, and uncover the secrets of the universe to survive.

With the endless cosmos surrounding you, every decision counts. The game immerses you in a space shooter experience like no other, where each battle tests your reflexes, strategy, and will to survive. The deeper you go into the void, the more you'll encounter strange phenomena and advanced alien technology, leading you on an unpredictable journey through the cosmos.

Key features include:

Intense Space Combat: Engage in fast-paced battles against alien ships and deadly obstacles, with a variety of weapons and upgrades at your disposal. Exploration of the Unknown: Uncover hidden secrets scattered throughout the void—each discovery brings you closer to understanding your purpose and how to escape the void. Challenging Obstacles: Navigate through asteroid fields, space anomalies, and dangerous environments that require quick thinking and precise control. Stunning Visuals and Sound: Experience the beauty and loneliness of deep space, with immersive visuals and an atmospheric soundtrack that complements the theme of isolation. Can you survive in the void and find your way back to safety? Or will you remain lost in space forever?

KEY CONTROLS:

<--(LEFT ARROW KEY) - MOVE SPACESHIP LEFT -->(RIGHT ARROW KEY) - MOVE SPACESHIP RIGHT (SPACE BAR) - SHOOT ALIENS

Credits: Game developed by Black Squad

Vamshidhar Mohan Vaishnavi S Sushmitha S Yeshwanth Gowda G

HOW TO RUN THE GAME?

1)Make sure you have installed Python 3.13 on your Windows 11/10/8/xp Or Mac
2)Install one of the code editors such as (RECOMMENDED Visual Studio Code or Pyjam) and Dont forget them to "ADD to the Path"
3)Now Install The Pygame Module in Your pc: 
i) Open Command Prompt in Windows/Mac 
ii) Copy and Paste the Code: pip install pygame Or if you are using python3 pip3 install pygame
iii)now Click on the gitHub Repository Link
iv) Download all the Files
v) Make Sure all the assets like images,sounds,mp3 files are associated with the python(.py) file
vi) Click on the "SOURCECODE.py"
vii)Click on Run
ENJOY YOUR GAME